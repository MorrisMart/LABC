This folder contains two pairs of input/output files, namely:

input_example_1.txt
output_example_1.txt
input_example_2.txt
output_example_2.txt 

which can be used to check correctness of your code and of the output format. Please note that

- The last line of the output files is meaningful only for those projects complying with the full assignment for 3 points.

- When the value of parameter alpha is in (0,1) you may expect some discrepancies in the lengths of the vertical lists associated with each entry, due to the randomness embodied in the method "generateEll(alpha, key)"
